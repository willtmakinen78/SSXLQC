import sys
sys.path.append("C:\\Users\\wmakinen\\Documents\\Summer 2019\\QC Automation\\SSXLQC")

from ssxlqc.run import run

if __name__ == '__main__':
    run()